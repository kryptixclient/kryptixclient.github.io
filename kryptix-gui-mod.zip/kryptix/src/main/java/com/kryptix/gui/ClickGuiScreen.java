package com.kryptix.gui; // paketi kendi projene göre değiştir

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.render.RenderPipelines;
import net.minecraft.text.Style;
import net.minecraft.text.StyleSpriteSource;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;

import java.util.*;

/**
 * Yarn mappings, Fabric 1.21.11.
 *
 * Dosya yerleşimi (NAMESPACE'i kendi mod id'n ile değiştir):
 *   src/main/resources/assets/NAMESPACE/font/gui.json
 *   src/main/resources/assets/NAMESPACE/font/font.ttf
 *   src/main/resources/assets/NAMESPACE/textures/gui/combat.png (misc, donut, render, client)
 *
 * Açmak için: MinecraftClient.getInstance().setScreen(new ClickGuiScreen());
 */
public class ClickGuiScreen extends Screen {

    // ---- AYARLAR ----
    private static final String NAMESPACE = "kryptix";
    private static final int ICON_TEX_SIZE = 128; // PNG'lerin gerçek piksel boyutu (128x128 değilse değiştir)

    private static final int PANEL_W = 108;
    private static final int HEADER_H = 20;
    private static final int ROW_H = 13;
    private static final int PAD = 4;
    private static final int GAP = 8;

    private static final int COL_PANEL = 0xF0121220;
    private static final int COL_BORDER = 0xFF1F1F33;
    private static final int COL_PURPLE = 0xFFA855F7;
    private static final int COL_TOGGLE_OFF = 0xFF3A3A48;
    private static final int COL_KNOB = 0xFFE8E8F0;
    private static final int COL_TEXT = 0xFFE6E6F0;
    private static final int COL_HOVER = 0x14FFFFFF;

    private static final Identifier FONT_ID = Identifier.of(NAMESPACE, "gui");
    private static final Style FONT_STYLE = Style.EMPTY.withFont(new StyleSpriteSource.Font(FONT_ID));

    // ---- MODÜL BAĞLANTISI: SADECE BU İKİ METODU KENDİ SİSTEMİNE BAĞLA ----
    private static final Set<String> FAKE_ENABLED = new HashSet<>(); // test için, bağlayınca sil

    private static boolean isEnabled(String moduleName) {
        // TODO: return ModuleManager.getByName(moduleName).isEnabled();
        return FAKE_ENABLED.contains(moduleName);
    }

    private static void toggle(String moduleName) {
        // TODO: ModuleManager.getByName(moduleName).toggle();
        if (!FAKE_ENABLED.remove(moduleName)) FAKE_ENABLED.add(moduleName);
    }

    // ---- PANELLER ----
    private static class Panel {
        final String title;
        final Identifier icon;
        final List<String> modules;
        int x, y;

        Panel(String title, List<String> modules) {
            this.title = title;
            this.modules = modules;
            this.icon = Identifier.of(NAMESPACE, "textures/gui/" + title.toLowerCase() + ".png");
        }

        int height() {
            return HEADER_H + PAD + modules.size() * ROW_H + PAD;
        }
    }

    // Konumlar oyun kapanana kadar korunur (static). Kalıcı kayıt istersen sonra ekleriz.
    private static final List<Panel> PANELS = new ArrayList<>();
    private static boolean positionsInitialized = false;
    private static final Map<String, Float> ANIM = new HashMap<>();

    static {
        PANELS.add(new Panel("Combat", List.of(
                "Auto Jump Reset", "Double Anchor", "Auto WTap", "Pearl Catch", "Shield Disabler",
                "Auto Inventory Totem", "Auto Pot Refill", "Auto Double Hand", "Shield Drain",
                "Trigger Bot", "Spear Lunge", "Crystal Optimizer", "Aim Assist", "Anchor Macro",
                "Auto Mace", "Auto Crystal", "Auto Hit Crystal")));
        PANELS.add(new Panel("Misc", List.of(
                "Auto Trident", "Schematic Builder", "Freecam", "Freelook")));
        PANELS.add(new Panel("Donut", List.of(
                "Player Finder", "Chunk Finder", "Sus Chunk Finder", "Auto Relog", "Pearl ESP",
                "Spawner Notifier", "Block Entity Debug")));
        PANELS.add(new Panel("Render", List.of(
                "Scoreboard Hider", "Player ESP", "Particles", "Storage ESP", "Fullbright",
                "Totem Glow", "Block ESP", "Block Outline", "Fast Place", "Name Protect",
                "Nametags", "Region Map", "Target HUD", "Custom Sky")));
        PANELS.add(new Panel("Client", List.of("Client", "HUD")));
    }

    private Panel dragging = null;
    private int dragOffX, dragOffY;

    public ClickGuiScreen() {
        super(Text.literal("ClickGUI"));
    }

    @Override
    protected void init() {
        if (!positionsInitialized) {
            int x = 10;
            for (Panel p : PANELS) {
                p.x = x;
                p.y = 10;
                x += PANEL_W + GAP;
            }
            positionsInitialized = true;
        }
    }

    @Override
    public boolean shouldPause() {
        return false;
    }

    // Arka planı karartma, oyun görünsün (görseldeki gibi)
    @Override
    public void renderBackground(DrawContext context, int mouseX, int mouseY, float delta) {
    }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        for (Panel p : PANELS) {
            renderPanel(ctx, p, mouseX, mouseY, delta);
        }
    }

    private void renderPanel(DrawContext ctx, Panel p, int mouseX, int mouseY, float delta) {
        int h = p.height();

        // gövde + ince kenarlık
        roundRect(ctx, p.x - 1, p.y - 1, PANEL_W + 2, h + 2, 5, COL_BORDER);
        roundRect(ctx, p.x, p.y, PANEL_W, h, 4, COL_PANEL);

        // başlık: ikon + yazı
        int iconSize = 10;
        int iconY = p.y + (HEADER_H - iconSize) / 2;
        ctx.drawTexture(RenderPipelines.GUI_TEXTURED, p.icon, p.x + 6, iconY,
                0f, 0f, iconSize, iconSize, ICON_TEX_SIZE, ICON_TEX_SIZE, ICON_TEX_SIZE, ICON_TEX_SIZE);
        drawText(ctx, p.title, p.x + 6 + iconSize + 5, p.y + (HEADER_H - 8) / 2, COL_TEXT);

        // başlık altı çizgi
        ctx.fill(p.x + 4, p.y + HEADER_H - 1, p.x + PANEL_W - 4, p.y + HEADER_H, COL_BORDER);

        // modül satırları
        int rowY = p.y + HEADER_H + PAD;
        for (String name : p.modules) {
            boolean hovered = mouseX >= p.x + 2 && mouseX < p.x + PANEL_W - 2
                    && mouseY >= rowY && mouseY < rowY + ROW_H;
            if (hovered) {
                ctx.fill(p.x + 3, rowY, p.x + PANEL_W - 3, rowY + ROW_H, COL_HOVER);
            }

            boolean on = isEnabled(name);
            float a = ANIM.getOrDefault(name, on ? 1f : 0f);
            float target = on ? 1f : 0f;
            a += (target - a) * Math.min(1f, delta * 0.35f);
            if (Math.abs(target - a) < 0.01f) a = target;
            ANIM.put(name, a);

            // yazı (açıkken mor)
            int textCol = on ? COL_PURPLE : COL_TEXT;
            drawText(ctx, name, p.x + 7, rowY + (ROW_H - 8) / 2, textCol);

            // toggle
            int tw = 16, th = 8;
            int tx = p.x + PANEL_W - tw - 7;
            int ty = rowY + (ROW_H - th) / 2;
            roundRect(ctx, tx, ty, tw, th, 4, lerpColor(COL_TOGGLE_OFF, COL_PURPLE, a));
            int knobSize = 6;
            int knobX = tx + 1 + Math.round((tw - knobSize - 2) * a);
            roundRect(ctx, knobX, ty + 1, knobSize, knobSize, 3, COL_KNOB);

            rowY += ROW_H;
        }
    }

    // ---- GİRDİ (1.21.9+ Click nesnesi kullanıyor) ----
    @Override
    public boolean mouseClicked(Click click, boolean doubled) {
        double mx = click.x(), my = click.y();
        int button = click.button();

        // üstteki panel önce: listeyi tersten tara
        for (int i = PANELS.size() - 1; i >= 0; i--) {
            Panel p = PANELS.get(i);
            if (mx < p.x || mx >= p.x + PANEL_W || my < p.y || my >= p.y + p.height()) continue;

            // öne getir
            PANELS.remove(i);
            PANELS.add(p);

            if (my < p.y + HEADER_H) {
                if (button == 0) {
                    dragging = p;
                    dragOffX = (int) mx - p.x;
                    dragOffY = (int) my - p.y;
                }
                return true;
            }

            int rowY = p.y + HEADER_H + PAD;
            for (String name : p.modules) {
                if (my >= rowY && my < rowY + ROW_H) {
                    if (button == 0) toggle(name);
                    return true;
                }
                rowY += ROW_H;
            }
            return true;
        }
        return super.mouseClicked(click, doubled);
    }

    @Override
    public boolean mouseDragged(Click click, double offsetX, double offsetY) {
        if (dragging != null && click.button() == 0) {
            dragging.x = clamp((int) click.x() - dragOffX, 0, width - PANEL_W);
            dragging.y = clamp((int) click.y() - dragOffY, 0, height - HEADER_H);
            return true;
        }
        return super.mouseDragged(click, offsetX, offsetY);
    }

    @Override
    public boolean mouseReleased(Click click) {
        dragging = null;
        return super.mouseReleased(click);
    }

    // ---- YARDIMCILAR ----
    private void drawText(DrawContext ctx, String s, int x, int y, int color) {
        ctx.drawText(textRenderer, Text.literal(s.toUpperCase()).setStyle(FONT_STYLE), x, y, color, false);
    }

    /** Yuvarlak köşeli dolu dikdörtgen (fill satırlarıyla). */
    private static void roundRect(DrawContext c, int x, int y, int w, int h, int r, int color) {
        r = Math.min(r, Math.min(w, h) / 2);
        for (int i = 0; i < r; i++) {
            double dy = r - i - 0.5;
            int inset = r - (int) Math.round(Math.sqrt(r * r - dy * dy));
            c.fill(x + inset, y + i, x + w - inset, y + i + 1, color);
            c.fill(x + inset, y + h - i - 1, x + w - inset, y + h - i, color);
        }
        c.fill(x, y + r, x + w, y + h - r, color);
    }

    private static int lerpColor(int from, int to, float t) {
        int a = (int) (((from >> 24) & 0xFF) + (((to >> 24) & 0xFF) - ((from >> 24) & 0xFF)) * t);
        int r = (int) (((from >> 16) & 0xFF) + (((to >> 16) & 0xFF) - ((from >> 16) & 0xFF)) * t);
        int g = (int) (((from >> 8) & 0xFF) + (((to >> 8) & 0xFF) - ((from >> 8) & 0xFF)) * t);
        int b = (int) ((from & 0xFF) + ((to & 0xFF) - (from & 0xFF)) * t);
        return (a << 24) | (r << 16) | (g << 8) | b;
    }

    private static int clamp(int v, int min, int max) {
        return Math.max(min, Math.min(max, v));
    }
}
