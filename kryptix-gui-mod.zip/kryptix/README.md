# Kryptix Client (sadece ClickGUI)

Fabric 1.21.11, Yarn mappings, Java 21. Menüyü açma tuşu: **Right Shift**.

## Build
Bilgisayarda: `gradle build` (Gradle 9.2+ ve Java 21) -> jar: `build/libs/kryptix-1.0.0.jar`
GitHub'da: repoya yükle, Actions sekmesinde `build` çalışır, jar "Artifacts" altında çıkar.

## Modülleri bağlama
`src/main/java/com/kryptix/gui/ClickGuiScreen.java` içindeki `isEnabled()` ve `toggle()`.
